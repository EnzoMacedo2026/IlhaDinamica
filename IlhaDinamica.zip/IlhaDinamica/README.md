# Ilha Dinâmica (sem root)

App Android comum que desenha uma "ilha" no topo da tela (pílula que expande em cards).
Versão sem root do módulo LSPosed `dynamicisland`, feita para o Galaxy A56 (One UI 9).
Não usa Xposed/LSPosed e não mexe no System UI.

## Cards da fase 1
- **Notificações** (mensagens), com botões de ação do próprio app (menos respostas com texto)
- **Códigos de verificação (OTP)** com botão Copiar
- **Progresso** (downloads etc.)
- **Chamadas** (pela notificação do discador: atender/recusar/desligar)
- **Música** (capa, título, anterior/play-pause/próxima)
- **Carregamento**, carga completa, bateria baixa
- **Fone** (com fio e Bluetooth de áudio)
- **Lanterna** (com botão Desligar)

## Como compilar
1. Android Studio: abra a pasta e use *Build > Build APK(s)* (debug já vem assinado), ou
2. Terminal: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`, ou
3. Suba a pasta num repositório GitHub: o workflow `.github/workflows/build.yml` gera o APK em *Actions > Artifacts*.

## Como configurar no celular
1. Instale o APK e abra o app.
2. Botão 1: permita *Sobrepor a outros apps*.
3. Botão 2: permita *Acesso a notificações*. Se o botão do Android estiver cinza ("configuração restrita"):
   Ajustes > Apps > Ilha Dinâmica > ⋮ (canto superior) > *Permitir configurações restritas*, e volte ao botão 2.
4. Botão 3: permita avisos e Bluetooth.
5. Toque em *Ligar ilha* e use os botões de teste. Ajuste a "distância do topo" até a pílula cobrir a câmera.
6. Para a ilha não ser fechada pelo sistema: Ajustes > Apps > Ilha Dinâmica > Bateria > *Sem restrições*.

## Limites (sem root)
- A ilha fica **abaixo do painel de notificações e da tela de bloqueio**.
- A cápsula Now Bar da Samsung continua aparecendo; não dá para escondê-la.
- Sem cards dentro do painel de notificações, sem heads-up takeover, sem blur real do fundo.
- Hotspot, cast, privacidade (câmera/microfone) e desbloqueio ficam para a fase 2.

## Estrutura
`Hub` guarda os cards ativos; `Overlay` desenha e anima a janela; as fontes (`ChargingSource`,
`HeadsetSource`, `TorchSource`, `MediaWatcher`, `IslandListener`) só postam `Card`s no `Hub`.
Para criar um card novo, crie um `Card` e chame `Hub.get().post(card)`.
