package app.ilhadinamica;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.List;

/** Um card da ilha: o que aparece na pílula e, expandido, no painel. */
public final class Card {
    public static final int P_LOW = 0;
    public static final int P_NORMAL = 1;
    public static final int P_HIGH = 2;
    public static final int P_URGENT = 3;

    public static final class Action {
        public final CharSequence label;
        /** 0 = botão de texto; senão um drawable do framework/app. */
        public final int iconRes;
        public final Runnable run;

        public Action(CharSequence label, int iconRes, Runnable run) {
            this.label = label;
            this.iconRes = iconRes;
            this.run = run;
        }
    }

    public final String key;
    public int priority = P_NORMAL;
    public Drawable icon;
    public Bitmap art;
    public CharSequence title = "";
    public CharSequence subtitle = "";
    /** Texto curto à direita da pílula compacta (ex.: "63%"). */
    public CharSequence trailing = "";
    /** 0..100, ou -1 sem barra. */
    public int progress = -1;
    public boolean indeterminate;
    /** Expande sozinho quando o card é novo ou muda de texto. */
    public boolean peek;
    /** SystemClock.uptimeMillis() em que o card some; 0 = fica até ser removido. */
    public long expiresAt;
    public Runnable onTap;
    public final List<Action> actions = new ArrayList<>();
    long updatedAt;

    public Card(String key) {
        this.key = key;
    }
}
