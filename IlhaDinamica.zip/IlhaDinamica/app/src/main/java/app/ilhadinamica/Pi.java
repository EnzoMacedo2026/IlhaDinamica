package app.ilhadinamica;

import android.app.ActivityOptions;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;

final class Pi {
    private Pi() {
    }

    static void send(Context c, PendingIntent pi) {
        if (pi == null) {
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                Bundle o = ActivityOptions.makeBasic()
                        .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                        .toBundle();
                pi.send(c, 0, null, null, null, null, o);
            } else {
                pi.send();
            }
        } catch (PendingIntent.CanceledException ignored) {
            // a notificação já foi cancelada pelo app
        }
    }
}
