package app.ilhadinamica;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Guarda os cards ativos (tudo na thread principal) e avisa a sobreposição. */
public final class Hub {
    public interface Listener {
        void onCardsChanged(List<Card> ordered, Card added);
    }

    private static final Hub INSTANCE = new Hub();

    public static Hub get() {
        return INSTANCE;
    }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, Card> cards = new LinkedHashMap<>();
    private final Runnable sweeper = this::sweepExpired;
    private Listener listener;

    private Hub() {
    }

    public void post(final Card c) {
        run(() -> {
            Card old = cards.get(c.key);
            boolean fresh = old == null || !same(old.title, c.title) || !same(old.subtitle, c.subtitle);
            c.updatedAt = (old != null && !fresh) ? old.updatedAt : SystemClock.uptimeMillis();
            cards.put(c.key, c);
            reschedule();
            changed(c.peek && fresh ? c : null);
        });
    }

    public void remove(final String key) {
        run(() -> {
            if (cards.remove(key) != null) {
                reschedule();
                changed(null);
            }
        });
    }

    public void setListener(final Listener l) {
        run(() -> {
            listener = l;
            if (l != null) {
                changed(null);
            }
        });
    }

    private void run(Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            r.run();
        } else {
            main.post(r);
        }
    }

    private static boolean same(CharSequence a, CharSequence b) {
        return String.valueOf(a).equals(String.valueOf(b));
    }

    private List<Card> ordered() {
        List<Card> list = new ArrayList<>(cards.values());
        Collections.sort(list, new Comparator<Card>() {
            @Override
            public int compare(Card a, Card b) {
                if (a.priority != b.priority) {
                    return b.priority - a.priority;
                }
                return Long.compare(b.updatedAt, a.updatedAt);
            }
        });
        return list;
    }

    private void changed(Card added) {
        if (listener != null) {
            listener.onCardsChanged(ordered(), added);
        }
    }

    private void reschedule() {
        main.removeCallbacks(sweeper);
        long now = SystemClock.uptimeMillis();
        long next = Long.MAX_VALUE;
        for (Card c : cards.values()) {
            if (c.expiresAt > 0) {
                next = Math.min(next, c.expiresAt);
            }
        }
        if (next != Long.MAX_VALUE) {
            main.postDelayed(sweeper, Math.max(30, next - now));
        }
    }

    private void sweepExpired() {
        long now = SystemClock.uptimeMillis();
        boolean changed = false;
        Iterator<Card> it = cards.values().iterator();
        while (it.hasNext()) {
            Card c = it.next();
            if (c.expiresAt > 0 && c.expiresAt <= now) {
                it.remove();
                changed = true;
            }
        }
        if (changed) {
            changed(null);
        }
        reschedule();
    }
}
