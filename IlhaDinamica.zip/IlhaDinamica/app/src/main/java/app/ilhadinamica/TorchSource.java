package app.ilhadinamica;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/** Lanterna ligada: card fixo com botão de desligar. */
final class TorchSource implements Source {
    private final Context ctx;
    private final CameraManager cm;
    private final Set<String> on = new HashSet<>();

    private final CameraManager.TorchCallback cb = new CameraManager.TorchCallback() {
        @Override
        public void onTorchModeChanged(String cameraId, boolean enabled) {
            if (enabled) {
                on.add(cameraId);
            } else {
                on.remove(cameraId);
            }
            render();
        }
    };

    TorchSource(Context ctx) {
        this.ctx = ctx;
        this.cm = ctx.getSystemService(CameraManager.class);
    }

    @Override
    public void start() {
        cm.registerTorchCallback(cb, new Handler(Looper.getMainLooper()));
    }

    @Override
    public void stop() {
        cm.unregisterTorchCallback(cb);
        on.clear();
        Hub.get().remove("torch");
    }

    private void render() {
        if (on.isEmpty()) {
            Hub.get().remove("torch");
            return;
        }
        Card c = new Card("torch");
        c.title = "Lanterna ligada";
        c.icon = Ui.icon(ctx, R.drawable.ic_flash);
        c.peek = true;
        c.actions.add(new Card.Action("Desligar", 0, new Runnable() {
            @Override
            public void run() {
                off();
            }
        }));
        Hub.get().post(c);
    }

    private void off() {
        for (String id : new ArrayList<>(on)) {
            try {
                cm.setTorchMode(id, false);
            } catch (CameraAccessException | IllegalArgumentException ignored) {
                // a câmera ficou indisponível
            }
        }
    }
}
