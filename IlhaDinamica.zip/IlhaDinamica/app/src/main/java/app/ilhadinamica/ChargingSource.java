package app.ilhadinamica;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.SystemClock;

/** Carregador conectado/desconectado, carga completa e bateria baixa. */
final class ChargingSource implements Source {
    private final Context ctx;
    private boolean init;
    private boolean plugged;
    private boolean fullShown;
    private boolean lowShown;

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            handle(i);
        }
    };

    ChargingSource(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    public void start() {
        Intent sticky = ctx.registerReceiver(rx, new IntentFilter(Intent.ACTION_BATTERY_CHANGED),
                Context.RECEIVER_NOT_EXPORTED);
        if (sticky != null) {
            handle(sticky);
        }
    }

    @Override
    public void stop() {
        try {
            ctx.unregisterReceiver(rx);
        } catch (RuntimeException ignored) {
            // não estava registrado
        }
        Hub.get().remove("charging");
        Hub.get().remove("battery_low");
    }

    private void handle(Intent i) {
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int pct = scale > 0 ? Math.round(level * 100f / scale) : level;
        int plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        boolean now = plug != 0;
        if (!init) {
            init = true;
            plugged = now;
            return;
        }
        if (now && !plugged) {
            fullShown = false;
            Hub.get().post(card("charging", "Carregando", plugLabel(plug), pct, 5000));
        } else if (!now && plugged) {
            Hub.get().post(card("charging", "Desconectado", "Bateria", pct, 3500));
        } else if (now && pct >= 100 && !fullShown) {
            fullShown = true;
            Hub.get().post(card("charging", "Carga completa", plugLabel(plug), 100, 6000));
        }
        if (!now && pct <= 15 && !lowShown) {
            lowShown = true;
            Card low = card("battery_low", "Bateria baixa", "Conecte o carregador", pct, 8000);
            low.priority = Card.P_HIGH;
            Hub.get().post(low);
        }
        if (pct > 20) {
            lowShown = false;
        }
        plugged = now;
    }

    private Card card(String key, String title, String sub, int pct, long ms) {
        Card c = new Card(key);
        c.title = title;
        c.subtitle = sub;
        c.trailing = pct + "%";
        c.progress = pct;
        c.icon = Ui.icon(ctx, R.drawable.ic_bolt);
        c.priority = Card.P_NORMAL;
        c.peek = true;
        c.expiresAt = SystemClock.uptimeMillis() + ms;
        return c;
    }

    private static String plugLabel(int plug) {
        if ((plug & BatteryManager.BATTERY_PLUGGED_WIRELESS) != 0) {
            return "Carregador sem fio";
        }
        if ((plug & BatteryManager.BATTERY_PLUGGED_USB) != 0) {
            return "USB";
        }
        return "Carregador";
    }
}
