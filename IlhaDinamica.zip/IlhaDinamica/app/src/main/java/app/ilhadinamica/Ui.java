package app.ilhadinamica;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.TextView;

final class Ui {
    static final int WHITE = 0xFFFFFFFF;
    static final int DIM = 0xB3FFFFFF;
    static final int FAINT = 0x33FFFFFF;

    private Ui() {
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static float clamp(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    static int lerp(int a, int b, float t) {
        return Math.round(a + (b - a) * t);
    }

    /** Drawable branco do app (vetores ic_*). */
    static Drawable icon(Context c, int res) {
        Drawable d = c.getDrawable(res).mutate();
        d.setTint(WHITE);
        return d;
    }

    /** Cópia independente, para o mesmo ícone aparecer em duas views. */
    static Drawable copy(Context c, Drawable d) {
        if (d == null) {
            return null;
        }
        Drawable.ConstantState cs = d.getConstantState();
        return cs != null ? cs.newDrawable(c.getResources()).mutate() : d;
    }

    static void round(View v, final float radiusPx) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
            }
        });
        v.setClipToOutline(true);
    }

    static TextView text(Context c, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        }
        return t;
    }
}
