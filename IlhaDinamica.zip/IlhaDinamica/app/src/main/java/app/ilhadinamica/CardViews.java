package app.ilhadinamica;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/** Monta a view de um card no painel expandido. */
final class CardViews {
    private CardViews() {
    }

    static View build(final Context c, final Card card, final Runnable afterTap) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (card.onTap != null) {
                    card.onTap.run();
                }
                if (afterTap != null) {
                    afterTap.run();
                }
            }
        });

        Drawable d = card.art != null ? new BitmapDrawable(c.getResources(), card.art) : Ui.copy(c, card.icon);
        if (d != null) {
            ImageView img = new ImageView(c);
            int size = Ui.dp(c, card.art != null ? 56 : 36);
            int pad = card.art != null ? 0 : Ui.dp(c, 6);
            img.setPadding(pad, pad, pad, pad);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setImageDrawable(d);
            Ui.round(img, Ui.dp(c, card.art != null ? 12 : 18));
            if (card.art == null) {
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Ui.FAINT);
                img.setBackground(bg);
            }
            row.addView(img, new LinearLayout.LayoutParams(size, size));
        }

        LinearLayout texts = new LinearLayout(c);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView title = Ui.text(c, 15, Ui.WHITE, true);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setText(card.title);
        texts.addView(title);
        if (card.subtitle != null && card.subtitle.length() > 0) {
            TextView sub = Ui.text(c, 13, Ui.DIM, false);
            sub.setMaxLines(2);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            sub.setText(card.subtitle);
            texts.addView(sub);
        }
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMarginStart(d != null ? Ui.dp(c, 12) : 0);
        row.addView(texts, tp);

        if (card.trailing != null && card.trailing.length() > 0) {
            TextView tr = Ui.text(c, 16, Ui.WHITE, true);
            tr.setText(card.trailing);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rp.setMarginStart(Ui.dp(c, 10));
            row.addView(tr, rp);
        }
        col.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        if (card.progress >= 0 || card.indeterminate) {
            ProgressBar pb = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
            pb.setProgressTintList(ColorStateList.valueOf(Ui.WHITE));
            pb.setProgressBackgroundTintList(ColorStateList.valueOf(Ui.FAINT));
            pb.setIndeterminateTintList(ColorStateList.valueOf(Ui.WHITE));
            if (card.progress >= 0) {
                pb.setIndeterminate(false);
                pb.setMax(100);
                pb.setProgress(card.progress);
            } else {
                pb.setIndeterminate(true);
            }
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 6));
            pp.topMargin = Ui.dp(c, 10);
            col.addView(pb, pp);
        }

        if (!card.actions.isEmpty()) {
            LinearLayout bar = new LinearLayout(c);
            bar.setOrientation(LinearLayout.HORIZONTAL);
            bar.setGravity(Gravity.CENTER);
            for (final Card.Action a : card.actions) {
                View b;
                LinearLayout.LayoutParams bp;
                if (a.iconRes != 0) {
                    ImageView iv = new ImageView(c);
                    int p = Ui.dp(c, 10);
                    iv.setPadding(p, p, p, p);
                    Drawable dr = c.getDrawable(a.iconRes).mutate();
                    dr.setTint(Ui.WHITE);
                    iv.setImageDrawable(dr);
                    iv.setContentDescription(a.label);
                    b = iv;
                    bp = new LinearLayout.LayoutParams(Ui.dp(c, 56), Ui.dp(c, 48));
                } else {
                    TextView tv = Ui.text(c, 14, Ui.WHITE, true);
                    tv.setGravity(Gravity.CENTER);
                    tv.setText(a.label);
                    tv.setSingleLine(true);
                    tv.setEllipsize(TextUtils.TruncateAt.END);
                    int ph = Ui.dp(c, 16);
                    int pv = Ui.dp(c, 9);
                    tv.setPadding(ph, pv, ph, pv);
                    GradientDrawable bg = new GradientDrawable();
                    bg.setColor(Ui.FAINT);
                    bg.setCornerRadius(Ui.dp(c, 20));
                    tv.setBackground(bg);
                    b = tv;
                    bp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    bp.setMarginStart(Ui.dp(c, 4));
                    bp.setMarginEnd(Ui.dp(c, 4));
                }
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        a.run.run();
                        if (afterTap != null && a.iconRes == 0) {
                            afterTap.run();
                        }
                    }
                });
                bar.addView(b, bp);
            }
            LinearLayout.LayoutParams barp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            barp.topMargin = Ui.dp(c, 10);
            col.addView(bar, barp);
        }
        return col;
    }
}
