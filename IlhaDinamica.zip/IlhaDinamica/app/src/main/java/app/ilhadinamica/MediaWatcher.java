package app.ilhadinamica;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Card de música a partir das sessões de mídia ativas. Precisa do acesso a notificações
 * (é ele que autoriza MediaSessionManager.getActiveSessions).
 */
final class MediaWatcher {
    private static final String KEY = "media";
    private static final long PAUSED_KEEP_MS = 8000;

    private final Context ctx;
    private final MediaSessionManager msm;
    private final ComponentName listener;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Map<MediaController, MediaController.Callback> callbacks = new HashMap<>();
    private List<MediaController> current = new ArrayList<>();
    private long pausedSince;
    private String pausedPkg = "";

    private final MediaSessionManager.OnActiveSessionsChangedListener sessions =
            new MediaSessionManager.OnActiveSessionsChangedListener() {
                @Override
                public void onActiveSessionsChanged(List<MediaController> list) {
                    bind(list);
                }
            };

    MediaWatcher(Context ctx, ComponentName listener) {
        this.ctx = ctx;
        this.listener = listener;
        this.msm = ctx.getSystemService(MediaSessionManager.class);
    }

    void start() {
        try {
            msm.addOnActiveSessionsChangedListener(sessions, listener, h);
            bind(msm.getActiveSessions(listener));
        } catch (SecurityException e) {
            // sem acesso a notificações ainda
        }
    }

    void stop() {
        try {
            msm.removeOnActiveSessionsChangedListener(sessions);
        } catch (RuntimeException ignored) {
            // já removido
        }
        clearCallbacks();
        h.removeCallbacksAndMessages(null);
        Hub.get().remove(KEY);
    }

    private void clearCallbacks() {
        for (Map.Entry<MediaController, MediaController.Callback> e : callbacks.entrySet()) {
            try {
                e.getKey().unregisterCallback(e.getValue());
            } catch (RuntimeException ignored) {
                // sessão já destruída
            }
        }
        callbacks.clear();
    }

    private void bind(List<MediaController> list) {
        clearCallbacks();
        current = list != null ? new ArrayList<>(list) : new ArrayList<MediaController>();
        for (MediaController mc : current) {
            MediaController.Callback cb = new MediaController.Callback() {
                @Override
                public void onPlaybackStateChanged(PlaybackState state) {
                    update();
                }

                @Override
                public void onMetadataChanged(MediaMetadata metadata) {
                    update();
                }

                @Override
                public void onSessionDestroyed() {
                    update();
                }
            };
            mc.registerCallback(cb, h);
            callbacks.put(mc, cb);
        }
        update();
    }

    private void update() {
        MediaController pick = null;
        boolean playing = false;
        for (MediaController mc : current) {
            PlaybackState s = mc.getPlaybackState();
            if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                pick = mc;
                playing = true;
                break;
            }
        }
        if (pick == null) {
            for (MediaController mc : current) {
                PlaybackState s = mc.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PAUSED) {
                    pick = mc;
                    break;
                }
            }
        }
        if (pick == null) {
            pausedSince = 0;
            Hub.get().remove(KEY);
            return;
        }

        long now = SystemClock.uptimeMillis();
        Card c = new Card(KEY);
        c.priority = Card.P_LOW;
        String pkg = pick.getPackageName();
        if (playing) {
            pausedSince = 0;
        } else {
            if (pausedSince == 0 || !pkg.equals(pausedPkg)) {
                pausedSince = now;
                pausedPkg = pkg;
            }
            c.expiresAt = pausedSince + PAUSED_KEEP_MS;
            if (c.expiresAt <= now) {
                Hub.get().remove(KEY);
                return;
            }
        }

        MediaMetadata m = pick.getMetadata();
        String title = null;
        String artist = null;
        Bitmap art = null;
        if (m != null) {
            title = m.getString(MediaMetadata.METADATA_KEY_TITLE);
            if (title == null) {
                title = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE);
            }
            artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST);
            if (artist == null) {
                artist = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
            }
            if (artist == null) {
                artist = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE);
            }
            art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (art == null) {
                art = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
            }
            if (art == null) {
                art = m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
            }
        }
        c.title = title != null ? title : "Reproduzindo";
        c.subtitle = artist != null ? artist : "";
        c.art = art;
        c.icon = Ui.icon(ctx, R.drawable.ic_music);
        c.peek = true;

        final MediaController.TransportControls tc = pick.getTransportControls();
        c.actions.add(new Card.Action("Anterior", android.R.drawable.ic_media_previous, new Runnable() {
            @Override
            public void run() {
                tc.skipToPrevious();
            }
        }));
        if (playing) {
            c.actions.add(new Card.Action("Pausar", android.R.drawable.ic_media_pause, new Runnable() {
                @Override
                public void run() {
                    tc.pause();
                }
            }));
        } else {
            c.actions.add(new Card.Action("Tocar", android.R.drawable.ic_media_play, new Runnable() {
                @Override
                public void run() {
                    tc.play();
                }
            }));
        }
        c.actions.add(new Card.Action("Próxima", android.R.drawable.ic_media_next, new Runnable() {
            @Override
            public void run() {
                tc.skipToNext();
            }
        }));

        final PendingIntent session = pick.getSessionActivity();
        final String pkgName = pkg;
        c.onTap = new Runnable() {
            @Override
            public void run() {
                if (session != null) {
                    Pi.send(ctx, session);
                    return;
                }
                Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(pkgName);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(launch);
                }
            }
        };
        Hub.get().post(c);
    }
}
