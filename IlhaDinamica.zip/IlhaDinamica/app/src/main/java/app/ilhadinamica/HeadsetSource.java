package app.ilhadinamica;

import android.Manifest;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.SystemClock;

/** Fone com fio e dispositivos de áudio Bluetooth conectando/desconectando. */
final class HeadsetSource implements Source {
    private final Context ctx;

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String action = i.getAction();
            if (Intent.ACTION_HEADSET_PLUG.equals(action)) {
                boolean on = i.getIntExtra("state", 0) == 1;
                show("Fone com fio", on);
            } else if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)
                    || BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                boolean on = BluetoothDevice.ACTION_ACL_CONNECTED.equals(action);
                handleBluetooth(d, on);
            }
        }
    };

    HeadsetSource(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    public void start() {
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_HEADSET_PLUG);
        f.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        ctx.registerReceiver(rx, f, Context.RECEIVER_EXPORTED);
    }

    @Override
    public void stop() {
        try {
            ctx.unregisterReceiver(rx);
        } catch (RuntimeException ignored) {
            // não estava registrado
        }
        Hub.get().remove("headset");
    }

    private void handleBluetooth(BluetoothDevice d, boolean on) {
        String name = "Bluetooth";
        boolean granted = ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                == PackageManager.PERMISSION_GRANTED;
        if (granted && d != null) {
            try {
                BluetoothClass bc = d.getBluetoothClass();
                if (bc != null && bc.getMajorDeviceClass() != BluetoothClass.Device.Major.AUDIO_VIDEO) {
                    return; // teclado, relógio etc.: não é fone
                }
                String n = d.getName();
                if (n != null && !n.isEmpty()) {
                    name = n;
                }
            } catch (SecurityException ignored) {
                // sem permissão: mostra o nome genérico
            }
        }
        show(name, on);
    }

    private void show(String name, boolean connected) {
        Card c = new Card("headset");
        c.title = name;
        c.subtitle = connected ? "Conectado" : "Desconectado";
        c.icon = Ui.icon(ctx, R.drawable.ic_headset);
        c.peek = true;
        c.expiresAt = SystemClock.uptimeMillis() + 4000;
        Hub.get().post(c);
    }
}
