package app.ilhadinamica;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Tela de ajustes: permissões, liga/desliga, posição e botões de teste. */
public final class MainActivity extends Activity {
    private TextView status;
    private Button toggle;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = Ui.dp(this, 20);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setTextSize(26);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        title.setText("Ilha Dinâmica");
        col.addView(title);

        status = new TextView(this);
        status.setTextSize(15);
        status.setPadding(0, pad / 2, 0, pad / 2);
        col.addView(status);

        col.addView(button("1. Permitir sobreposição a outros apps", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        }));
        col.addView(button("2. Permitir acesso a notificações", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        }));
        col.addView(button("3. Permitir avisos e Bluetooth", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermissions(new String[]{
                        Manifest.permission.POST_NOTIFICATIONS,
                        Manifest.permission.BLUETOOTH_CONNECT}, 1);
            }
        }));
        toggle = button("", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleService();
            }
        });
        col.addView(toggle);

        Switch peek = new Switch(this);
        peek.setText("Expandir sozinho com novidades");
        peek.setChecked(Prefs.peek(this));
        peek.setPadding(0, pad / 2, 0, pad / 2);
        peek.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean on) {
                Prefs.sp(MainActivity.this).edit().putBoolean(Prefs.PEEK, on).apply();
            }
        });
        col.addView(peek);

        TextView posLabel = new TextView(this);
        posLabel.setText("Distância do topo (ajuste até a pílula cobrir a câmera)");
        col.addView(posLabel);
        SeekBar pos = new SeekBar(this);
        pos.setMax(40);
        pos.setProgress(Prefs.topDp(this));
        pos.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                Prefs.sp(MainActivity.this).edit().putInt(Prefs.TOP, p).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        col.addView(pos);

        TextView tests = new TextView(this);
        tests.setText("\nTestar (ligue a ilha antes)");
        tests.setTextSize(16);
        col.addView(tests);
        col.addView(button("Notificação", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testNotification();
            }
        }));
        col.addView(button("Código de verificação", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testOtp();
            }
        }));
        col.addView(button("Carregando", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testCharging();
            }
        }));
        col.addView(button("Download com progresso", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testProgress();
            }
        }));
        col.addView(button("Música", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testMusic();
            }
        }));

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private Button button(String label, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setAllCaps(false);
        bt.setOnClickListener(l);
        bt.setGravity(Gravity.CENTER);
        return bt;
    }

    private boolean listenerOk() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        return nm.isNotificationListenerAccessGranted(new ComponentName(this, IslandListener.class));
    }

    private void refresh() {
        boolean overlay = Settings.canDrawOverlays(this);
        boolean listener = listenerOk();
        status.setText((overlay ? "✔" : "✖") + " Sobreposição a outros apps\n"
                + (listener ? "✔" : "✖") + " Acesso a notificações (notificações, códigos, música, chamadas)\n"
                + (IslandService.running ? "✔" : "✖") + " Ilha ligada");
        toggle.setText(IslandService.running ? "Desligar ilha" : "Ligar ilha");
    }

    private void toggleService() {
        if (IslandService.running) {
            stopService(new Intent(this, IslandService.class));
            Prefs.sp(this).edit().putBoolean(Prefs.ENABLED, false).apply();
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permita a sobreposição primeiro (botão 1)", Toast.LENGTH_LONG).show();
                return;
            }
            startForegroundService(new Intent(this, IslandService.class));
            Prefs.sp(this).edit().putBoolean(Prefs.ENABLED, true).apply();
        }
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                refresh();
            }
        }, 400);
    }

    // ---- testes --------------------------------------------------------------------------------

    private void testNotification() {
        Card c = new Card("test:n");
        c.title = "Maria";
        c.subtitle = "Oi! Já está chegando?";
        c.icon = Ui.icon(this, R.drawable.ic_bell);
        c.peek = true;
        c.expiresAt = SystemClock.uptimeMillis() + 6000;
        Hub.get().post(c);
    }

    private void testOtp() {
        Card c = new Card("test:otp");
        c.title = "Código 482913";
        c.subtitle = "Seu banco";
        c.icon = Ui.icon(this, R.drawable.ic_bell);
        c.priority = Card.P_HIGH;
        c.peek = true;
        c.expiresAt = SystemClock.uptimeMillis() + 15000;
        c.actions.add(new Card.Action("Copiar", 0, new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Copiaria 482913", Toast.LENGTH_SHORT).show();
            }
        }));
        Hub.get().post(c);
    }

    private void testCharging() {
        Card c = new Card("test:charging");
        c.title = "Carregando";
        c.subtitle = "Carregador";
        c.trailing = "63%";
        c.progress = 63;
        c.icon = Ui.icon(this, R.drawable.ic_bolt);
        c.peek = true;
        c.expiresAt = SystemClock.uptimeMillis() + 6000;
        Hub.get().post(c);
    }

    private void testProgress() {
        Card c = new Card("test:progress");
        c.title = "Baixando arquivo";
        c.subtitle = "atualizacao.apk";
        c.trailing = "42%";
        c.progress = 42;
        c.icon = Ui.icon(this, R.drawable.ic_bolt);
        c.peek = true;
        c.expiresAt = SystemClock.uptimeMillis() + 8000;
        Hub.get().post(c);
    }

    private void testMusic() {
        Card c = new Card("test:music");
        c.title = "Música de teste";
        c.subtitle = "Artista";
        c.icon = Ui.icon(this, R.drawable.ic_music);
        c.peek = true;
        c.expiresAt = SystemClock.uptimeMillis() + 9000;
        Runnable noop = new Runnable() {
            @Override
            public void run() {
            }
        };
        c.actions.add(new Card.Action("Anterior", android.R.drawable.ic_media_previous, noop));
        c.actions.add(new Card.Action("Pausar", android.R.drawable.ic_media_pause, noop));
        c.actions.add(new Card.Action("Próxima", android.R.drawable.ic_media_next, noop));
        Hub.get().post(c);
    }
}
