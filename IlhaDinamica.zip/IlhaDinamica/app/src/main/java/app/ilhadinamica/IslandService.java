package app.ilhadinamica;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;

import java.util.ArrayList;
import java.util.List;

/** Mantém a sobreposição e as fontes de cards vivas em segundo plano. */
public final class IslandService extends Service {
    private static final String CHANNEL = "ilha";
    static volatile boolean running;

    private Overlay overlay;
    private final List<Source> sources = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Ilha Dinâmica", NotificationManager.IMPORTANCE_MIN));
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_bolt)
                .setContentTitle("Ilha Dinâmica ativa")
                .setContentText("Toque para abrir os ajustes")
                .setContentIntent(open)
                .setOngoing(true)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);

        overlay = new Overlay(this);
        Hub.get().setListener(overlay);
        sources.add(new ChargingSource(this));
        sources.add(new HeadsetSource(this));
        sources.add(new TorchSource(this));
        for (Source s : sources) {
            try {
                s.start();
            } catch (RuntimeException e) {
                // uma fonte com problema não derruba as outras
            }
        }
        running = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        for (Source s : sources) {
            try {
                s.stop();
            } catch (RuntimeException ignored) {
                // já parada
            }
        }
        sources.clear();
        Hub.get().setListener(null);
        if (overlay != null) {
            overlay.destroy();
            overlay = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
