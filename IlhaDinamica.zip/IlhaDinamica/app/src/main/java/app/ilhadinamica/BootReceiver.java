package app.ilhadinamica;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

/** Religa a ilha depois que o celular reinicia, se ela estava ligada. */
public final class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
                && Prefs.enabled(context) && Settings.canDrawOverlays(context)) {
            context.startForegroundService(new Intent(context, IslandService.class));
        }
    }
}
