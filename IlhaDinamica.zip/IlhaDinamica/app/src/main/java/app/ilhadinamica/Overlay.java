package app.ilhadinamica;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Collections;
import java.util.List;

/**
 * A janela da ilha: uma sobreposição (TYPE_APPLICATION_OVERLAY) no topo da tela que alterna entre
 * pílula compacta e painel expandido. Não precisa de root, mas fica por baixo do painel de
 * notificações e da tela de bloqueio.
 */
final class Overlay implements Hub.Listener, SharedPreferences.OnSharedPreferenceChangeListener {
    private static final long ANIM_MS = 380;
    private static final long PEEK_MS = 4500;
    private static final long OPEN_MS = 9000;

    private final Context ctx;
    private final WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final FrameLayout root;
    private final LinearLayout compact;
    private final ImageView cIcon;
    private final TextView cTitle;
    private final TextView cTrail;
    private final LinearLayout expanded;
    private final GradientDrawable bg = new GradientDrawable();
    private final WindowManager.LayoutParams lp;
    private final GestureDetector gestures;
    private final Runnable autoCollapse = new Runnable() {
        @Override
        public void run() {
            collapse();
        }
    };

    private List<Card> cards = Collections.emptyList();
    private boolean attached;
    private boolean isExpanded;
    private ValueAnimator anim;
    private float radius;

    Overlay(Context context) {
        ctx = context;
        wm = ctx.getSystemService(WindowManager.class);

        bg.setColor(Color.BLACK);
        root = new FrameLayout(ctx);
        root.setBackground(bg);
        root.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
            }
        });
        root.setClipToOutline(true);

        compact = new LinearLayout(ctx);
        compact.setOrientation(LinearLayout.HORIZONTAL);
        compact.setGravity(Gravity.CENTER_VERTICAL);
        compact.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 7), Ui.dp(ctx, 14), Ui.dp(ctx, 7));
        cIcon = new ImageView(ctx);
        cIcon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Ui.round(cIcon, Ui.dp(ctx, 6));
        compact.addView(cIcon, new LinearLayout.LayoutParams(Ui.dp(ctx, 20), Ui.dp(ctx, 20)));
        cTitle = Ui.text(ctx, 13, Ui.WHITE, true);
        cTitle.setSingleLine(true);
        cTitle.setEllipsize(TextUtils.TruncateAt.END);
        cTitle.setMaxWidth(Ui.dp(ctx, 170));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.setMarginStart(Ui.dp(ctx, 8));
        compact.addView(cTitle, tp);
        cTrail = Ui.text(ctx, 12, Ui.DIM, true);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.setMarginStart(Ui.dp(ctx, 8));
        compact.addView(cTrail, rp);
        root.addView(compact, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        expanded = new LinearLayout(ctx);
        expanded.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(ctx, 16);
        expanded.setPadding(pad, pad, pad, pad);
        expanded.setVisibility(View.GONE);
        expanded.setAlpha(0f);
        root.addView(expanded, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        gestures = new GestureDetector(ctx, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                if (isExpanded) {
                    collapse();
                } else {
                    expand(false);
                }
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (vy < -600 && isExpanded) {
                    collapse();
                    return true;
                }
                if (vy > 600 && !isExpanded) {
                    expand(false);
                    return true;
                }
                return false;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                if (!cards.isEmpty()) {
                    Hub.get().remove(cards.get(0).key);
                }
            }
        });
        root.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                    if (isExpanded) {
                        collapse();
                    }
                    return true;
                }
                return gestures.onTouchEvent(e);
            }
        });

        lp = new WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.setTitle("IlhaDinamica");
        lp.y = Ui.dp(ctx, Prefs.topDp(ctx));

        Prefs.sp(ctx).registerOnSharedPreferenceChangeListener(this);
    }

    void destroy() {
        Prefs.sp(ctx).unregisterOnSharedPreferenceChangeListener(this);
        h.removeCallbacksAndMessages(null);
        cancelAnim();
        root.animate().cancel();
        detach();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        if (Prefs.TOP.equals(key)) {
            lp.y = Ui.dp(ctx, Prefs.topDp(ctx));
            if (attached) {
                wm.updateViewLayout(root, lp);
            }
        }
    }

    @Override
    public void onCardsChanged(List<Card> ordered, Card added) {
        cards = ordered;
        if (ordered.isEmpty()) {
            hide();
            return;
        }
        if (!Settings.canDrawOverlays(ctx)) {
            return;
        }
        root.animate().cancel();
        root.setAlpha(1f);
        boolean first = !attached;
        refreshCompact();
        if (first) {
            attach();
        }
        if (isExpanded) {
            rebuildExpanded();
            animateTo(true, false);
        } else if (!first) {
            animateTo(false, false);
        }
        if (added != null && Prefs.peek(ctx)) {
            if (isExpanded) {
                scheduleAutoCollapse(PEEK_MS);
            } else {
                expand(true);
            }
        }
    }

    // ---- janela --------------------------------------------------------------------------------

    private void attach() {
        int[] s = compactSize();
        lp.width = s[0];
        lp.height = s[1];
        lp.y = Ui.dp(ctx, Prefs.topDp(ctx));
        compact.setAlpha(1f);
        compact.setVisibility(View.VISIBLE);
        expanded.setVisibility(View.GONE);
        applyShape(lp.height);
        root.setAlpha(0f);
        try {
            wm.addView(root, lp);
            attached = true;
            root.animate().alpha(1f).setDuration(180).start();
        } catch (RuntimeException e) {
            attached = false;
        }
    }

    private void detach() {
        if (attached) {
            try {
                wm.removeView(root);
            } catch (RuntimeException ignored) {
                // já removida
            }
            attached = false;
        }
        isExpanded = false;
    }

    private void hide() {
        if (!attached) {
            return;
        }
        cancelAnim();
        h.removeCallbacks(autoCollapse);
        isExpanded = false;
        root.animate().alpha(0f).setDuration(180).withEndAction(new Runnable() {
            @Override
            public void run() {
                if (cards.isEmpty()) {
                    detach();
                }
            }
        }).start();
    }

    // ---- estados -------------------------------------------------------------------------------

    void expand(boolean auto) {
        if (!attached || cards.isEmpty() || isExpanded) {
            return;
        }
        isExpanded = true;
        rebuildExpanded();
        expanded.setVisibility(View.VISIBLE);
        lp.flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        animateTo(true, true);
        scheduleAutoCollapse(auto ? PEEK_MS : OPEN_MS);
    }

    void collapse() {
        if (!isExpanded) {
            return;
        }
        isExpanded = false;
        h.removeCallbacks(autoCollapse);
        lp.flags &= ~WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        if (!cards.isEmpty()) {
            refreshCompact();
        }
        compact.setVisibility(View.VISIBLE);
        compact.setAlpha(0f);
        animateTo(false, true);
    }

    private void scheduleAutoCollapse(long ms) {
        h.removeCallbacks(autoCollapse);
        h.postDelayed(autoCollapse, ms);
    }

    // ---- conteúdo ------------------------------------------------------------------------------

    private void refreshCompact() {
        Card top = cards.get(0);
        Drawable d = top.art != null ? new BitmapDrawable(ctx.getResources(), top.art) : Ui.copy(ctx, top.icon);
        if (d != null) {
            cIcon.setImageDrawable(d);
            cIcon.setVisibility(View.VISIBLE);
        } else {
            cIcon.setVisibility(View.GONE);
        }
        CharSequence t = top.title != null && top.title.length() > 0 ? top.title : top.subtitle;
        cTitle.setText(t);
        CharSequence trail = top.trailing;
        if ((trail == null || trail.length() == 0) && cards.size() > 1) {
            trail = "+" + (cards.size() - 1);
        }
        boolean has = trail != null && trail.length() > 0;
        cTrail.setText(has ? trail : "");
        cTrail.setVisibility(has ? View.VISIBLE : View.GONE);
    }

    private void rebuildExpanded() {
        expanded.removeAllViews();
        int n = Math.min(3, cards.size());
        for (int i = 0; i < n; i++) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i > 0) {
                p.topMargin = Ui.dp(ctx, 16);
            }
            expanded.addView(CardViews.build(ctx, cards.get(i), new Runnable() {
                @Override
                public void run() {
                    collapse();
                }
            }), p);
        }
    }

    // ---- medidas e animação --------------------------------------------------------------------

    private int screenW() {
        return wm.getCurrentWindowMetrics().getBounds().width();
    }

    private int[] compactSize() {
        int sw = screenW();
        compact.measure(
                View.MeasureSpec.makeMeasureSpec(sw, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int w = Math.max(compact.getMeasuredWidth(), Ui.dp(ctx, 110));
        w = Math.min(w, (int) (sw * 0.85f));
        int hgt = Math.max(compact.getMeasuredHeight(), Ui.dp(ctx, 34));
        return new int[]{w, hgt};
    }

    private int[] expandedSize() {
        int w = Math.min(screenW() - 2 * Ui.dp(ctx, 10), Ui.dp(ctx, 480));
        expanded.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        return new int[]{w, expanded.getMeasuredHeight()};
    }

    private void applyShape(int heightPx) {
        radius = Math.min(heightPx / 2f, Ui.dp(ctx, 28));
        bg.setCornerRadius(radius);
        root.invalidateOutline();
    }

    private void cancelAnim() {
        if (anim != null) {
            anim.removeAllListeners();
            anim.removeAllUpdateListeners();
            anim.cancel();
            anim = null;
        }
    }

    private void animateTo(final boolean toExpanded, final boolean modeChange) {
        if (!attached) {
            return;
        }
        int[] target = toExpanded ? expandedSize() : compactSize();
        final int tw = target[0];
        final int th = target[1];
        final int fw = lp.width;
        final int fh = lp.height;
        final int maxW = screenW();
        cancelAnim();
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(modeChange ? ANIM_MS : 260);
        a.setInterpolator(toExpanded ? new OvershootInterpolator(0.85f) : new DecelerateInterpolator(1.6f));
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                float f = (float) va.getAnimatedValue();
                lp.width = Math.max(1, Math.min(maxW, Ui.lerp(fw, tw, f)));
                lp.height = Math.max(1, Ui.lerp(fh, th, f));
                applyShape(lp.height);
                if (modeChange) {
                    float t = Ui.clamp(f);
                    if (toExpanded) {
                        compact.setAlpha(1f - Ui.clamp(t / 0.35f));
                        expanded.setAlpha(Ui.clamp((t - 0.3f) / 0.6f));
                    } else {
                        expanded.setAlpha(1f - Ui.clamp(t / 0.4f));
                        compact.setAlpha(Ui.clamp((t - 0.5f) / 0.5f));
                    }
                }
                if (attached) {
                    wm.updateViewLayout(root, lp);
                }
            }
        });
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                lp.width = tw;
                lp.height = th;
                applyShape(th);
                if (modeChange) {
                    if (toExpanded) {
                        compact.setVisibility(View.GONE);
                        expanded.setAlpha(1f);
                    } else {
                        expanded.setVisibility(View.GONE);
                        compact.setAlpha(1f);
                    }
                }
                if (attached) {
                    wm.updateViewLayout(root, lp);
                }
            }
        });
        anim = a;
        a.start();
    }
}
