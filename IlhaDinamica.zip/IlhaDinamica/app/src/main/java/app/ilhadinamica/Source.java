package app.ilhadinamica;

/** Uma fonte de cards (carregamento, fone, lanterna...). */
interface Source {
    void start();

    void stop();
}
