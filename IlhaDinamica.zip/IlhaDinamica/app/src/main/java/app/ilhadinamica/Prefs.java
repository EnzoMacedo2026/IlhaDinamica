package app.ilhadinamica;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String FILE = "ilha";
    static final String TOP = "top_dp";
    static final String PEEK = "peek";
    static final String ENABLED = "enabled";

    private Prefs() {
    }

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static int topDp(Context c) {
        return sp(c).getInt(TOP, 6);
    }

    static boolean peek(Context c) {
        return sp(c).getBoolean(PEEK, true);
    }

    static boolean enabled(Context c) {
        return sp(c).getBoolean(ENABLED, false);
    }
}
