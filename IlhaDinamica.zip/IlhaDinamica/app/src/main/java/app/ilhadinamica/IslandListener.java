package app.ilhadinamica;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Transforma notificações em cards: mensagens, códigos de verificação, progresso (downloads),
 * chamadas. Também liga o card de música (MediaWatcher).
 */
public final class IslandListener extends NotificationListenerService {
    private static final Pattern CODE = Pattern.compile("(?<!\\d)(\\d{4,8})(?!\\d)");
    private static final Pattern CODE_WORDS = Pattern.compile(
            "(?i)(c[oó]digo|code|verifica|verification|senha|otp|token|\\bpin\\b|confirma|autentica|login|acesso)");

    private MediaWatcher media;

    @Override
    public void onListenerConnected() {
        media = new MediaWatcher(this, new ComponentName(this, IslandListener.class));
        media.start();
        try {
            StatusBarNotification[] active = getActiveNotifications();
            if (active != null) {
                for (StatusBarNotification sbn : active) {
                    handle(sbn, false);
                }
            }
        } catch (RuntimeException ignored) {
            // serviço ainda não pronto
        }
    }

    @Override
    public void onListenerDisconnected() {
        if (media != null) {
            media.stop();
            media = null;
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        handle(sbn, true);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        Hub.get().remove("n:" + sbn.getKey());
    }

    private void handle(final StatusBarNotification sbn, boolean live) {
        final Notification n = sbn.getNotification();
        Bundle ex = n.extras;
        if (ex == null || sbn.getPackageName().equals(getPackageName())) {
            return;
        }
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0
                || ex.containsKey(Notification.EXTRA_MEDIA_SESSION)
                || Notification.CATEGORY_TRANSPORT.equals(n.category)) {
            return;
        }
        CharSequence title = ex.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = ex.getCharSequence(Notification.EXTRA_TEXT);
        if (text == null) {
            text = ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
        }
        if (title == null && text == null) {
            return;
        }

        int importance = NotificationManager.IMPORTANCE_DEFAULT;
        try {
            RankingMap rm = getCurrentRanking();
            Ranking r = new Ranking();
            if (rm != null && rm.getRanking(sbn.getKey(), r)) {
                importance = r.getImportance();
            }
        } catch (RuntimeException ignored) {
            // usa o padrão
        }
        if (importance <= NotificationManager.IMPORTANCE_NONE) {
            return;
        }

        boolean ongoing = (n.flags & Notification.FLAG_ONGOING_EVENT) != 0;
        boolean isCall = Notification.CATEGORY_CALL.equals(n.category);
        int max = ex.getInt(Notification.EXTRA_PROGRESS_MAX);
        int cur = ex.getInt(Notification.EXTRA_PROGRESS);
        boolean indet = ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE);
        boolean hasProgress = max > 0 || indet;

        Card c = new Card("n:" + sbn.getKey());
        c.title = title != null ? title : "";
        c.subtitle = text != null ? text : "";
        c.icon = iconOf(sbn);
        c.onTap = new Runnable() {
            @Override
            public void run() {
                Pi.send(IslandListener.this, n.contentIntent);
            }
        };
        long now = SystemClock.uptimeMillis();

        if (isCall) {
            c.priority = Card.P_URGENT;
            c.peek = live;
            addActions(c, n, 3);
        } else if (hasProgress) {
            c.priority = Card.P_NORMAL;
            c.peek = live;
            if (max > 0) {
                c.progress = Math.min(100, Math.max(0, cur * 100 / max));
                c.trailing = c.progress + "%";
                if (c.progress >= 100) {
                    c.expiresAt = now + 3000;
                }
            } else {
                c.indeterminate = true;
            }
            addActions(c, n, 2);
        } else if (ongoing || !live || importance < NotificationManager.IMPORTANCE_DEFAULT) {
            return;
        } else {
            String blob = (title != null ? title : "") + " " + (text != null ? text : "");
            String code = null;
            if (CODE_WORDS.matcher(blob).find()) {
                Matcher m = CODE.matcher(blob);
                if (m.find()) {
                    code = m.group(1);
                }
            }
            if (code != null) {
                final String found = code;
                c.title = "Código " + found;
                c.subtitle = title != null ? title : "";
                c.priority = Card.P_HIGH;
                c.peek = true;
                c.expiresAt = now + 25000;
                c.onTap = new Runnable() {
                    @Override
                    public void run() {
                        copy(found);
                    }
                };
                c.actions.add(new Card.Action("Copiar", 0, c.onTap));
            } else {
                c.priority = Card.P_NORMAL;
                c.peek = true;
                c.expiresAt = now + 6000;
                addActions(c, n, 2);
            }
        }
        Hub.get().post(c);
    }

    private void addActions(Card c, Notification n, int limit) {
        if (n.actions == null) {
            return;
        }
        int added = 0;
        for (final Notification.Action a : n.actions) {
            if (a.actionIntent == null || a.title == null) {
                continue;
            }
            if (a.getRemoteInputs() != null && a.getRemoteInputs().length > 0) {
                continue; // resposta com texto: não dá para disparar sem digitar
            }
            c.actions.add(new Card.Action(a.title, 0, new Runnable() {
                @Override
                public void run() {
                    Pi.send(IslandListener.this, a.actionIntent);
                }
            }));
            if (++added >= limit) {
                break;
            }
        }
    }

    private void copy(String code) {
        ClipboardManager cm = getSystemService(ClipboardManager.class);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("código", code));
        }
    }

    private Drawable iconOf(StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        try {
            Icon big = n.getLargeIcon();
            if (big != null) {
                Drawable d = big.loadDrawable(this);
                if (d != null) {
                    return d;
                }
            }
        } catch (RuntimeException ignored) {
            // tenta o ícone pequeno
        }
        try {
            Icon small = n.getSmallIcon();
            if (small != null) {
                Drawable d = small.loadDrawable(this);
                if (d != null) {
                    d = d.mutate();
                    d.setTint(Color.WHITE);
                    return d;
                }
            }
        } catch (RuntimeException ignored) {
            // tenta o ícone do app
        }
        try {
            return getPackageManager().getApplicationIcon(sbn.getPackageName());
        } catch (Exception ignored) {
            return null;
        }
    }
}
